#ifndef __CB_H__
#define __CB_H__


typedef struct circular_buffer {
    uint8_t buffer[128];
}