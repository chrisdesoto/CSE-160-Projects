//Author: Chris DeSoto
//$LastChangedDate: 2018-10-14 21:38:00 -0700 (Tues, 09 Oct 2018) $

#ifndef LS_PROTOCOL_H
#define LS_PROTOCOL_H

// Link state vars
#define LS_MAX_ROUTES 256
#define LS_MAX_COST 17
#define LS_TTL 17


#endif /* LS_PROTOCOL_H */